import cv2

# Load the image
image = cv2.imread('hand.png')

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Canny edge detection
canny_edges = cv2.Canny(gray_image, threshold1=150, threshold2=300)  # You can adjust the thresholds as needed

# Draw boundaries on the original image
contours, _ = cv2.findContours(canny_edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
cv2.drawContours(image, contours, -1, (255, 0, 0), thickness=3)  # Red color for the boundaries

# Display the image with boundaries
cv2.imshow('Image with Boundaries', image)
cv2.waitKey(0)
cv2.destroyAllWindows()
