import cv2

# Reading an image in default mode
image = cv2.imread('pngimg.com - bouquet_PNG31.png')

# Define the new width and height for the resized image
new_width = 800  # Adjust this value as needed
aspect_ratio = image.shape[1] / image.shape[0]
new_height = int(new_width / aspect_ratio)

# Resize the image
resized_image = cv2.resize(image, (new_width, new_height))

# Window name for the resized image
window_name = 'Resized Image'

center_coordinates = (500, 200)

# Radius of circle
radius = 100

# Blue color in BGR
color = (255, 0, 0)

# Line thickness of 4 px
thickness = 4

# Using cv2.circle() method
# Draw a circle with blue line borders of thickness of 4 px
image = cv2.circle(resized_image, center_coordinates, radius, color, thickness)

# Displaying the resized image
cv2.imshow(window_name, resized_image)

import numpy as np

# Define the coordinates and dimensions of the rectangle
x, y = 200, 250  # Top-left corner of the rectangle
width_rect, height_rect = 200, 100  # Width and height of the rectangle
color = (0, 0, 255)  # Red color in BGR format

# Draw the rectangle on the image
image = cv2.rectangle(image, (x, y), (x + width_rect, y + height_rect), color, thickness=2)

# Display the image with the rectangle
cv2.imshow(window_name, resized_image)

# Define the coordinates of the line
start_point = (50, 110)
end_point = (500, 300)
color = (0, 255, 0)  # Green color in BGR format
thickness = 2  # Line thickness

# Draw the line on the image
image = cv2.line(image, start_point, end_point, color, thickness)

# Display the image with the line
cv2.imshow(window_name, resized_image)


# Define the text and its position
text = "Hello, World!"
font = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 1
font_color = (0, 255, 255)  # Yellow color in BGR format
font_thickness = 4
position = (400, 400)  # (x, y) coordinates

# Write the text on the image
image = cv2.putText(image, text, position, font, font_scale, font_color, font_thickness, lineType=cv2.LINE_AA)

# Display the image with the text
cv2.imshow(window_name, resized_image)

# Wait for a key press and then close the window
cv2.waitKey(0)
cv2.destroyAllWindows()
